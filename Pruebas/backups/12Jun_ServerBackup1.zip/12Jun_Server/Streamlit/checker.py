import json
import requests
import yaml
from datetime import datetime
import os
from emailsender import enviar_alerta

UMBRAL_FILE = "umbral_config.json"
LOG_FILE = "logs_alertas.json"
CONFIG_FILE = "config.yaml"
USUARIOS_FILE = "usuarios.json"

def cargar_configuracion_general():
    config = {
        "influxdb_url": os.getenv('INFLUXDB_URL', 'http://influxdb:8086'),
        "token": os.getenv('INFLUXDB_TOKEN', 'token_telegraf'),
        "org": os.getenv('INFLUXDB_ORG', 'power_logic'),
        "notificaciones_generales": False
    }
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg_from_file = yaml.safe_load(f)
                if cfg_from_file:
                    if "notificaciones_generales" in cfg_from_file:
                        config["notificaciones_generales"] = cfg_from_file["notificaciones_generales"]
        else:
            print(f"[INFO] El archivo '{CONFIG_FILE}' no existe. Usando configuración por defecto.")
    except Exception as e:
        print(f"[ERROR] Error al leer {CONFIG_FILE}: {e}. Usando configuración por defecto.")
    return config

def cargar_configuracion_umbral():
    try:
        if os.path.exists(UMBRAL_FILE):
            with open(UMBRAL_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        else:
            print(f"[WARNING] El archivo '{UMBRAL_FILE}' no existe. Retornando umbrales vacíos.")
            return {}
    except json.JSONDecodeError as e:
        print(f"[ERROR] Error al decodificar JSON de '{UMBRAL_FILE}': {e}. Retornando umbrales vacíos.")
        return {}
    except Exception as e:
        print(f"[ERROR] Error al cargar '{UMBRAL_FILE}': {e}. Retornando umbrales vacíos.")
        return {}


def cargar_usuarios_con_alertas():
    try:
        if os.path.exists(USUARIOS_FILE):
            with open(USUARIOS_FILE, "r", encoding="utf-8") as f:
                usuarios = json.load(f)
            # Ahora buscamos el 'alert_email'
            return [u.get("alert_email") for u in usuarios if u.get("recibir_notificaciones", False) and u.get("alert_email")]
        else:
            print(f"[WARNING] El archivo '{USUARIOS_FILE}' no existe. No se enviarán correos.")
            return []
    except json.JSONDecodeError as e:
        print(f"[ERROR] Error al decodificar JSON de '{USUARIOS_FILE}': {e}. No se enviarán correos.")
        return []
    except Exception as e:
        print(f"[ERROR] Error al cargar '{USUARIOS_FILE}': {e}. No se enviarán correos.")
        return []

def registrar_alerta(variable, valor, umbral_info):
    umbral_str = f"Min: {umbral_info.get('min', 'N/A')}, Max: {umbral_info.get('max', 'N/A')}"
    entrada = {
        "timestamp": datetime.now().isoformat(),
        "variable": variable,
        "valor": valor,
        "umbral": umbral_str
    }
    try:
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, "r", encoding="utf-8") as f:
                logs = json.load(f)
        else:
            logs = []
    except json.JSONDecodeError:
        logs = []
        print(f"[WARNING] El archivo '{LOG_FILE}' está corrupto o vacío. Se reiniciará el log de alertas.")
    except FileNotFoundError:
        logs = []
    except Exception as e:
        logs = []
        print(f"[ERROR] Error inesperado al leer '{LOG_FILE}': {e}. Se reiniciará el log de alertas.")


    logs.append(entrada)

    MAX_LOG_ENTRIES = 100
    if len(logs) > MAX_LOG_ENTRIES:
        logs = logs[-MAX_LOG_ENTRIES:]

    try:
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            json.dump(logs, f, indent=4)
    except Exception as e:
        print(f"[ERROR] No se pudo escribir en '{LOG_FILE}': {e}")


def consultar_influx_y_verificar():
    config = cargar_configuracion_general()
    umbrales = cargar_configuracion_umbral()

    INFLUX_URL = config["influxdb_url"] + "/api/v2/query"
    TOKEN = config["token"]
    ORG = config["org"]
    ENVIAR_MAIL_GLOBAL = config.get("notificaciones_generales", False)

    headers = {
        "Authorization": f"Token {TOKEN}",
        "Content-Type": "application/vnd.flux"
    }

    destinatarios = cargar_usuarios_con_alertas() if ENVIAR_MAIL_GLOBAL else []

    alertas_encontradas = False

    for variable_field_name, umbral_data in umbrales.items():
        min_umbral = umbral_data.get('min')
        max_umbral = umbral_data.get('max')

        flux_query = f'''
        from(bucket: "powerlogic_warnings_tmp")
          |> range(start: -2m)
          |> filter(fn: (r) => r["_field"] == "{variable_field_name}")
          |> last()
        '''

        try:
            response = requests.post(INFLUX_URL, headers=headers, data=flux_query, params={"org": ORG})
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            print(f"[ERROR] No se pudo consultar InfluxDB para {variable_field_name}: {e}")
            continue

        valor = None
        for line in response.text.splitlines():
            if not line.startswith("#") and "_result" in line:
                partes = line.split(",")
                for parte in reversed(partes):
                    try:
                        valor = float(parte)
                        break
                    except ValueError:
                        continue
                if valor is not None:
                    break

        if valor is not None:
            alerta_activa = False
            mensaje_alerta = []

            if min_umbral is not None and valor < min_umbral:
                mensaje_alerta.append(f"{variable_field_name} ({valor:.2f}) está por debajo del umbral mínimo ({min_umbral:.2f}).")
                alerta_activa = True
            
            if max_umbral is not None and valor > max_umbral:
                mensaje_alerta.append(f"{variable_field_name} ({valor:.2f}) está por encima del umbral máximo ({max_umbral:.2f}).")
                alerta_activa = True
            
            if alerta_activa:
                alertas_encontradas = True
                print(f"[ALERTA] {' '.join(mensaje_alerta)}")
                registrar_alerta(variable_field_name, valor, umbral_data)

                if destinatarios:
                    hora = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    mensaje_html = (
                        f"<h2>Alerta de PowerLogic</h2>"
                        f"<p><strong>Variable:</strong> {variable_field_name}</p>"
                        f"<p><strong>Valor actual:</strong> {valor:.2f}</p>"
                        f"<p><strong>Umbrales configurados:</strong> Min: {min_umbral:.2f}, Max: {max_umbral:.2f}</p>"
                        f"<p><strong>Motivo:</strong> {' '.join(mensaje_alerta)}</p>"
                        f"<p><em>Hora:</em> {hora}</p>"
                    )
                    for email in destinatarios:
                        print(f"Intentando enviar correo a {email}...")
                        enviar_alerta(email, f"⚠️ Alerta: {variable_field_name} - Umbral Superado/Bajo", mensaje_html)
                else:
                    print(f"No hay destinatarios configurados para enviar alerta de {variable_field_name}.")
            else:
                print(f"[OK] {variable_field_name} = {valor:.2f} (dentro de umbrales)")
        else:
            print(f"[INFO] No se encontró valor para {variable_field_name} en los últimos 2 minutos.")
    
    if not alertas_encontradas:
        print("[INFO] No se cumplen condiciones de alerta para ninguna métrica.")


if __name__ == "__main__":
    consultar_influx_y_verificar()
