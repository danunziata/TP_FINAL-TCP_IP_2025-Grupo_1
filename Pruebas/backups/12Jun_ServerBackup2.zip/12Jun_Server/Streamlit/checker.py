import json
import requests
import yaml
from datetime import datetime, timedelta
import os
from emailsender import enviar_alerta
import argparse # Importar para manejar argumentos de línea de comandos

UMBRAL_FILE = "umbral_config.json"
LOG_FILE = "logs_alertas.json"
CONFIG_FILE = "config.yaml"
USUARIOS_FILE = "usuarios.json"
# Nuevo archivo para el estado de cooldown de las alertas
COOLDOWN_STATE_FILE = "alert_cooldown_state.json"
# Período de cooldown en segundos (ej. 5 minutos)
COOLDOWN_PERIOD_SECONDS = 300

def cargar_configuracion_general():
    config = {
        "influxdb_url": os.getenv('INFLUXDB_URL', 'http://influxdb:8086'),
        "token": os.getenv('INFLUXDB_TOKEN', 'token_telegraf'),
        "org": os.getenv('INFLUXDB_ORG', 'power_logic'),
        "notificaciones_generales": False
    }
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg_from_file = yaml.safe_load(f)
                if cfg_from_file:
                    if "notificaciones_generales" in cfg_from_file:
                        config["notificaciones_generales"] = cfg_from_file["notificaciones_generales"]
        else:
            print(f"[INFO] El archivo '{CONFIG_FILE}' no existe. Usando configuración por defecto.")
    except Exception as e:
        print(f"[ERROR] Error al leer {CONFIG_FILE}: {e}. Usando configuración por defecto.")
    return config

def cargar_configuracion_umbral():
    try:
        if os.path.exists(UMBRAL_FILE):
            with open(UMBRAL_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        else:
            print(f"[WARNING] El archivo '{UMBRAL_FILE}' no existe. Retornando umbrales vacíos.")
            return {}
    except json.JSONDecodeError as e:
        print(f"[ERROR] Error al decodificar JSON de '{UMBRAL_FILE}': {e}. Retornando umbrales vacíos.")
        return {}
    except Exception as e:
        print(f"[ERROR] Error al cargar '{UMBRAL_FILE}': {e}. Retornando umbrales vacíos.")
        return {}

def cargar_usuarios_con_alertas():
    try:
        if os.path.exists(USUARIOS_FILE):
            with open(USUARIOS_FILE, "r", encoding="utf-8") as f:
                usuarios = json.load(f)
            # Ahora buscamos el 'alert_email'
            return [u.get("alert_email") for u in usuarios if u.get("recibir_notificaciones", False) and u.get("alert_email")]
        else:
            print(f"[WARNING] El archivo '{USUARIOS_FILE}' no existe. No se enviarán correos.")
            return []
    except json.JSONDecodeError as e:
        print(f"[ERROR] Error al decodificar JSON de '{USUARIOS_FILE}': {e}. No se enviarán correos.")
        return []
    except Exception as e:
        print(f"[ERROR] Error al cargar '{USUARIOS_FILE}': {e}. No se enviarán correos.")
        return []

def registrar_alerta(variable, valor, umbral_info, tipo_ejecucion="automatico"): # Añadido tipo_ejecucion
    umbral_str = f"Min: {umbral_info.get('min', 'N/A')}, Max: {umbral_info.get('max', 'N/A')}"
    entrada = {
        "timestamp": datetime.now().isoformat(),
        "variable": variable,
        "valor": valor,
        "umbral": umbral_str,
        "tipo_ejecucion": tipo_ejecucion # Registrar el tipo de ejecución
    }
    try:
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, "r", encoding="utf-8") as f:
                logs = json.load(f)
        else:
            logs = []
    except json.JSONDecodeError:
        logs = []
        print(f"[WARNING] El archivo '{LOG_FILE}' está corrupto o vacío. Se reiniciará el log de alertas.")
    except FileNotFoundError:
        logs = []
    except Exception as e:
        logs = []
        print(f"[ERROR] Error inesperado al leer '{LOG_FILE}': {e}. Se reiniciará el log de alertas.")

    logs.append(entrada)

    MAX_LOG_ENTRIES = 100
    if len(logs) > MAX_LOG_ENTRIES:
        logs = logs[-MAX_LOG_ENTRIES:]

    try:
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            json.dump(logs, f, indent=4)
    except Exception as e:
        print(f"[ERROR] No se pudo escribir en '{LOG_FILE}': {e}")

def load_cooldown_state():
    """Carga el estado de cooldown de las alertas desde un archivo."""
    if os.path.exists(COOLDOWN_STATE_FILE):
        try:
            with open(COOLDOWN_STATE_FILE, "r", encoding="utf-8") as f:
                state = json.load(f)
            # Convertir las cadenas de fecha a objetos datetime
            for key, timestamp_str in state.items():
                state[key] = datetime.fromisoformat(timestamp_str)
            return state
        except (json.JSONDecodeError, FileNotFoundError, ValueError) as e:
            print(f"[WARNING] Error al cargar el estado de cooldown '{COOLDOWN_STATE_FILE}': {e}. Iniciando con estado vacío.")
            return {}
    return {}

def save_cooldown_state(state):
    """Guarda el estado de cooldown de las alertas en un archivo."""
    # Convertir objetos datetime a cadenas ISO para serialización
    serializable_state = {key: dt_obj.isoformat() for key, dt_obj in state.items()}
    try:
        with open(COOLDOWN_STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(serializable_state, f, indent=4)
    except Exception as e:
        print(f"[ERROR] No se pudo guardar el estado de cooldown en '{COOLDOWN_STATE_FILE}': {e}")

def consultar_influx_y_verificar(manual_run=False):
    config = cargar_configuracion_general()
    umbrales = cargar_configuracion_umbral()

    INFLUX_URL = config["influxdb_url"] + "/api/v2/query"
    TOKEN = config["token"]
    ORG = config["org"]
    ENVIAR_MAIL_GLOBAL = config.get("notificaciones_generales", False)

    headers = {
        "Authorization": f"Token {TOKEN}",
        "Content-Type": "application/vnd.flux"
    }

    # Destinatarios para envío de email (solo si no es una ejecución manual)
    destinatarios = cargar_usuarios_con_alertas() if ENVIAR_MAIL_GLOBAL and not manual_run else []

    alertas_encontradas = False
    cooldown_state = load_cooldown_state()
    current_time = datetime.now()

    for variable_field_name, umbral_data in umbrales.items():
        min_umbral = umbral_data.get('min')
        max_umbral = umbral_data.get('max')

        flux_query = f'''
        from(bucket: "powerlogic_warnings_tmp")
          |> range(start: -2m)
          |> filter(fn: (r) => r["_field"] == "{variable_field_name}")
          |> last()
        '''

        try:
            response = requests.post(INFLUX_URL, headers=headers, data=flux_query, params={"org": ORG})
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            print(f"[ERROR] No se pudo consultar InfluxDB para {variable_field_name}: {e}")
            continue

        valor = None
        for line in response.text.splitlines():
            if not line.startswith("#") and "_result" in line:
                partes = line.split(",")
                for parte in reversed(partes):
                    try:
                        valor = float(parte)
                        break
                    except ValueError:
                        continue
                if valor is not None:
                    break

        if valor is not None:
            alerta_activa = False
            mensaje_alerta = []
            alert_key = f"{variable_field_name}_min" if min_umbral is not None and valor < min_umbral else ""
            alert_key = f"{variable_field_name}_max" if max_umbral is not None and valor > max_umbral else alert_key

            if min_umbral is not None and valor < min_umbral:
                mensaje_alerta.append(f"{variable_field_name} ({valor:.2f}) está por debajo del umbral mínimo ({min_umbral:.2f}).")
                alerta_activa = True
            
            if max_umbral is not None and valor > max_umbral:
                mensaje_alerta.append(f"{variable_field_name} ({valor:.2f}) está por encima del umbral máximo ({max_umbral:.2f}).")
                alerta_activa = True
            
            if alerta_activa:
                alertas_encontradas = True
                print(f"[ALERTA] {' '.join(mensaje_alerta)} (Tipo: {'Manual' if manual_run else 'Automático'})")
                registrar_alerta(variable_field_name, valor, umbral_data, "manual" if manual_run else "automatico")

                # Lógica de Cooldown para envío de correos (solo para ejecuciones automáticas)
                if not manual_run and destinatarios:
                    last_sent_time = cooldown_state.get(alert_key)
                    # Si no se ha enviado antes o ha pasado el período de cooldown
                    if last_sent_time is None or (current_time - last_sent_time).total_seconds() > COOLDOWN_PERIOD_SECONDS:
                        hora = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        mensaje_html = (
                            f"<h2>Alerta de PowerLogic</h2>"
                            f"<p><strong>Variable:</strong> {variable_field_name}</p>"
                            f"<p><strong>Valor actual:</strong> {valor:.2f}</p>"
                            f"<p><strong>Umbrales configurados:</strong> Min: {min_umbral:.2f}, Max: {max_umbral:.2f}</p>"
                            f"<p><strong>Motivo:</strong> {' '.join(mensaje_alerta)}</p>"
                            f"<p><em>Hora:</em> {hora}</p>"
                        )
                        for email in destinatarios:
                            print(f"Intentando enviar correo a {email}...")
                            enviar_alerta(email, f"⚠️ Alerta: {variable_field_name} - Umbral Superado/Bajo", mensaje_html)
                        
                        # Actualizar el estado de cooldown
                        cooldown_state[alert_key] = current_time
                        save_cooldown_state(cooldown_state)
                    else:
                        print(f"[INFO] Alerta para {variable_field_name} detectada, pero en cooldown. No se envía correo.")
                elif manual_run:
                    # En modo manual, no se envían correos a la lista de destinatarios
                    print(f"[INFO] Alerta para {variable_field_name} detectada en ejecución manual. No se envían correos a destinatarios.")
                else:
                    print(f"[INFO] No hay destinatarios configurados o notificaciones globales desactivadas para enviar alerta de {variable_field_name}.")
            else:
                print(f"[OK] {variable_field_name} = {valor:.2f} (dentro de umbrales)")
                # Si una alerta estaba activa y ahora se resuelve, podrías limpiar su estado de cooldown aquí
                if alert_key and alert_key in cooldown_state:
                    print(f"[INFO] Alerta para {variable_field_name} resuelta. Limpiando estado de cooldown.")
                    del cooldown_state[alert_key]
                    save_cooldown_state(cooldown_state)
        else:
            print(f"[INFO] No se encontró valor para {variable_field_name} en los últimos 2 minutos.")
    
    if not alertas_encontradas:
        print("[INFO] No se cumplen condiciones de alerta para ninguna métrica.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Script para consultar InfluxDB y verificar umbrales de alerta.")
    parser.add_argument('--manual-run', action='store_true', help='Indica que la ejecución es manual y no debe enviar correos a la lista global de destinatarios.')
    args = parser.parse_args()
    
    consultar_influx_y_verificar(manual_run=args.manual_run)
